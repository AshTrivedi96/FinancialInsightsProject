

<main id="main">

    <section class="inner-page" style="padding: 150px 0">
      <div class="container">
        
        <div class="section-title" data-aos="zoom-out">
          <h2>Stocks</h2>
          <p>Live Stock</p>
        </div>
       
        <table class="table table-striped " id="live_stock_table">
            <thead>
              
              <th>Ticker</th>
              <th>Name</th>
              <th>Market</th>
              <th>Locale</th>
              <th>Currency</th> 
            </thead>
            <tbody>
          
            </tbody>
        </table>
        
      </div>
  </section>
</main>

